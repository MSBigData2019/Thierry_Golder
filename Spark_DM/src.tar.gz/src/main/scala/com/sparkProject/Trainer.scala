package com.sparkProject

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.feature._
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.evaluation.{MulticlassClassificationEvaluator}
import org.apache.spark.ml.tuning.{ParamGridBuilder, TrainValidationSplit}
import org.apache.log4j.{Logger, Level}


object Trainer {

  def main(args: Array[String]): Unit = {

    Logger.getLogger("org").setLevel(Level.WARN)


    val conf = new SparkConf().setAll(Map(
      "spark.scheduler.mode" -> "FIFO",
      "spark.speculation" -> "false",
      "spark.reducer.maxSizeInFlight" -> "48m",
      "spark.serializer" -> "org.apache.spark.serializer.KryoSerializer",
      "spark.kryoserializer.buffer.max" -> "1g",
      "spark.shuffle.file.buffer" -> "32k",
      "spark.default.parallelism" -> "12",
      "spark.sql.shuffle.partitions" -> "12",
      "spark.driver.maxResultSize" -> "2g"
    ))

    val spark = SparkSession
      .builder
      .config(conf)
      .appName("TP_spark")
      .getOrCreate()


    /*******************************************************************************
      *
      *       TP 3
      *
      *       - lire le fichier sauvegarder précédemment
      *       - construire les Stages du pipeline, puis les assembler
      *       - trouver les meilleurs hyperparamètres pour l'entraînement du pipeline avec une grid-search
      *       - Sauvegarder le pipeline entraîné
      *
      *       if problems with unimported modules => sbt plugins update
      *
      ********************************************************************************/

    println("hello world ! from Trainer")

    var parquetFilePath = new String("/cal/homes/tgolder/TP_ParisTech_2017_2018_starter/prepared_trainingset/")

    var trainedDf = spark.read.parquet(parquetFilePath+"part-00000-da4490f3-3af7-4783-a4a9-64355a59cb83-c000.snappy.parquet")

    for (i <- 1 to 7) {
      trainedDf = trainedDf.union(spark.read.parquet(parquetFilePath + "part-0000" + i.toString() + "-da4490f3-3af7-4783-a4a9-64355a59cb83-c000.snappy.parquet"))
    }

    val tokenizer = new RegexTokenizer()
        .setPattern("\\W+")
        .setGaps(true)
        .setInputCol("text")
        .setOutputCol("tokens")

   // val trainedTokenizedDf = tokenizer.transform(trainedDf)


    StopWordsRemover.loadDefaultStopWords("english")

    val remover = new StopWordsRemover()
      .setInputCol("tokens")
      .setOutputCol("clean-tokens")

   // var trainedCleanedDf = remover.transform(trainedTokenizedDf)


   // val cvModel: CountVectorizerModel = new CountVectorizer()
    val vectorizer = new CountVectorizer()
      .setInputCol("clean-tokens")
      .setOutputCol("vectorized_tokens")
   //   .setMinDF(2)
   //   .fit(trainedCleanedDf)

   // trainedCleanedDf = cvModel.transform(trainedCleanedDf)

   //trainedCleanedDf.select("country2").dropDuplicates().show()
   //trainedCleanedDf.select("currency2").dropDuplicates().show()

    val idf = new IDF()
      .setInputCol("vectorized_tokens")
      .setOutputCol("tfidf")


    val indexCountry = new StringIndexer()
      .setInputCol("country2")
      .setOutputCol("country_indexed")
      .setHandleInvalid("skip")
   //   .fit(trainedCleanedDf)

   // var indexedTrainedCleanedDf = indexCountry.transform(trainedCleanedDf)

    //indexedTrainedCleanedDf.select("country_indexed").show()

    val indexCurrency = new StringIndexer()
      .setInputCol("currency2")
      .setOutputCol("currency_indexed")
      .setHandleInvalid("skip")
    //  .fit(indexedTrainedCleanedDf)

    // indexedTrainedCleanedDf = indexCurrency.transform(indexedTrainedCleanedDf)

   // indexedTrainedCleanedDf.select("country2", "country_indexed").dropDuplicates().show()
   // indexedTrainedCleanedDf.select( "currency2", "currency_indexed").dropDuplicates().show()


    val countryEncoder = new OneHotEncoder()
     .setInputCol("country_indexed")
     .setOutputCol("country_vec_indexed")

   // var vectIndexedTrainedCleanedDf = countryEncoder.transform(indexedTrainedCleanedDf)

    val currencyEncoder = new OneHotEncoder()
     .setInputCol("currency_indexed")
     .setOutputCol("currency_vec_indexed")

   // vectIndexedTrainedCleanedDf = currencyEncoder.transform(vectIndexedTrainedCleanedDf)

   // vectIndexedTrainedCleanedDf.select("country2", "country_vec_indexed").dropDuplicates().show()
   // vectIndexedTrainedCleanedDf.select( "currency2", "currency_vec_indexed").dropDuplicates().show()

    //vectIndexedTrainedCleanedDf.show()

    val assembler = new VectorAssembler()
      .setInputCols(Array("tfidf", "days_campaign", "hours_prepa", "goal", "country_vec_indexed", "currency_vec_indexed"))
      .setOutputCol("features")

    //val assembledTrainedDf = assembler.transform(vectIndexedTrainedCleanedDf)
   // assembledTrainedDf.select("tfidf", "days_campaign", "hours_prepa", "goal", "country_vec_indexed", "currency_vec_indexed", "features").show()
   // assembledTrainedDf.select( "features").show()

    val lr = new LogisticRegression()
      .setElasticNetParam(0.0)
      .setFitIntercept(true)
      .setFeaturesCol("features")
      .setLabelCol("final_status")
      .setStandardization(true)
      .setPredictionCol("predictions")
      .setRawPredictionCol("raw_predictions")
      .setThresholds(Array(0.7,0.3))
      .setTol(1.0e-6)
      .setMaxIter(300)

    val pipeline = new Pipeline()
      .setStages(Array(tokenizer, remover, vectorizer, idf, indexCountry, indexCurrency,countryEncoder, currencyEncoder, assembler, lr))


   // val model = pipeline.fit(trainedDf)


    //val Array(trainingset, testset) = AssembledTrainedDf.randomSplit(Array(0.9, 0.1))

    val paramGrid = new ParamGridBuilder()
      .addGrid(lr.regParam, Array(1.0e-8, 1.0e-6, 1.0e-4, 1.0e-2))
      .addGrid(vectorizer.minDF, Array(55.0, 75.0, 95.0))
      .build()

    val mce = new MulticlassClassificationEvaluator()
      .setMetricName("f1")
      .setLabelCol("final_status")
      .setPredictionCol("predictions")


    val trainValidationSplit = new TrainValidationSplit()
      .setEstimator(pipeline)
      .setEvaluator(mce)
      .setEstimatorParamMaps(paramGrid)
      .setTrainRatio(0.7)


    val Array(training, test) = trainedDf.randomSplit(Array(0.9, 0.1), seed = 123456)


    val model = trainValidationSplit.fit(training)

    val predictions = model.transform(test)

    val score_final = mce.evaluate(predictions)

    println("f1 score: "+ score_final)

    predictions.groupBy("final_status", "predictions").count.show()

    lr.save("/cal/homes/tgolder/TP_ParisTech_2017_2018_starter/trained_LR_model.model")

  }
}
